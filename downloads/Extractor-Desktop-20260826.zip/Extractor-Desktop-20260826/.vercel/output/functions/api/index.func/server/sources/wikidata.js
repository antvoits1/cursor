import { fetchPage } from '../transport.js';
function firstStringClaim(claims, property) {
    const entries = claims?.[property];
    if (!entries)
        return undefined;
    for (const entry of entries) {
        const value = entry.mainsnak?.datavalue?.value;
        if (typeof value === 'string' && value.trim())
            return value.trim();
    }
    return undefined;
}
async function fetchJson(url, label, trace) {
    const outcome = await fetchPage(url, { label, trace, timeoutMs: 10000 });
    if (!outcome.ok || !outcome.html)
        return null;
    try {
        return JSON.parse(outcome.html);
    }
    catch {
        return null;
    }
}
/** Resolves a company name to its Wikidata entity and declared official website. */
export async function lookupEntityFacts(name, trace) {
    const cleaned = name.trim();
    if (cleaned.length < 3)
        return null;
    trace.info('discovery', `Checking the Wikidata public knowledge base for "${cleaned}"...`, { sourceLabel: 'Wikidata' });
    const searchUrl = `https://www.wikidata.org/w/api.php?action=wbsearchentities&type=item&limit=3&language=en&format=json&origin=*` +
        `&search=${encodeURIComponent(cleaned)}`;
    const search = await fetchJson(searchUrl, 'the Wikidata search endpoint', trace);
    const candidate = search?.search?.[0];
    if (!candidate) {
        trace.info('discovery', `Wikidata has no entry for "${cleaned}".`, { sourceLabel: 'Wikidata' });
        return null;
    }
    const entityUrl = `https://www.wikidata.org/w/api.php?action=wbgetentities&format=json&origin=*&props=labels|descriptions|claims` +
        `&languages=en&ids=${encodeURIComponent(candidate.id)}`;
    const entities = await fetchJson(entityUrl, 'the Wikidata entity record', trace);
    const entity = entities?.entities?.[candidate.id];
    if (!entity)
        return null;
    const officialWebsite = firstStringClaim(entity.claims, 'P856');
    const facts = {
        entityId: candidate.id,
        label: entity.labels?.en?.value ?? candidate.label,
        description: entity.descriptions?.en?.value ?? candidate.description,
        officialWebsite,
        sourceUrl: `https://www.wikidata.org/wiki/${candidate.id}`,
    };
    if (officialWebsite) {
        trace.success('discovery', `Wikidata lists ${officialWebsite} as the declared official website for ${facts.label}.`, {
            sourceLabel: 'Wikidata',
            url: facts.sourceUrl,
        });
    }
    else {
        trace.info('discovery', `Wikidata has an entry for ${facts.label} but does not declare an official website.`, {
            sourceLabel: 'Wikidata',
            url: facts.sourceUrl,
        });
    }
    return facts;
}
/** DuckDuckGo's documented Instant Answer API, used when Wikidata search misses. */
export async function lookupInstantAnswer(query, trace) {
    const url = `https://api.duckduckgo.com/?q=${encodeURIComponent(query)}&format=json&no_html=1&skip_disambig=1`;
    const data = await fetchJson(url, 'the DuckDuckGo Instant Answer service', trace);
    if (!data?.Heading)
        return null;
    trace.success('discovery', `The DuckDuckGo knowledge service recognises "${data.Heading}".`, {
        sourceLabel: 'DuckDuckGo Instant Answer',
    });
    return { heading: data.Heading, abstract: data.AbstractText, url: data.AbstractURL };
}
//# sourceMappingURL=wikidata.js.map