/**
 * Per-run route recorder.
 *
 * A trace belongs to exactly one extraction. Nothing is shared across runs,
 * which is what keeps concurrent single and bulk extractions from mixing their
 * evidence into each other.
 */
export class RouteTrace {
    listener;
    steps = [];
    startedAt = Date.now();
    seq = 0;
    /**
     * @param listener Called as each step is recorded so the API can stream the
     * route to the browser while the run is still in progress.
     */
    constructor(listener) {
        this.listener = listener;
    }
    add(kind, status, message, options = {}) {
        const step = {
            seq: (this.seq += 1),
            kind,
            status,
            message,
            atMs: Date.now() - this.startedAt,
            ...options,
        };
        this.steps.push(step);
        // A misbehaving listener must not abort an extraction that is otherwise fine.
        if (this.listener) {
            try {
                this.listener(step);
            }
            catch {
                /* ignored on purpose */
            }
        }
        return step;
    }
    info(kind, message, options) {
        return this.add(kind, 'info', message, options);
    }
    success(kind, message, options) {
        return this.add(kind, 'success', message, options);
    }
    warn(kind, message, options) {
        return this.add(kind, 'warning', message, options);
    }
    error(kind, message, options) {
        return this.add(kind, 'error', message, options);
    }
    skip(kind, message, options) {
        return this.add(kind, 'skipped', message, options);
    }
    elapsedMs() {
        return Date.now() - this.startedAt;
    }
    snapshot() {
        return this.steps.map((s) => ({ ...s }));
    }
    count() {
        return this.steps.length;
    }
}
//# sourceMappingURL=trace.js.map