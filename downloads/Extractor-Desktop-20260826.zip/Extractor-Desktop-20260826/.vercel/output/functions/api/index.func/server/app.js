import express from 'express';
import { BUILD_NAME, BUILD_VERSION, extract, getDiagnostics, planQuery, resetEngineStats, } from './engine.js';
import { resetLearning, snapshot as learningSnapshot } from './learning.js';
const MAX_QUERY_LENGTH = 400;
function fail(res, status, error, detail) {
    const body = detail ? { error, detail } : { error };
    res.status(status).json(body);
}
function asString(value) {
    return typeof value === 'string' ? value : '';
}
export function createApiRouter(host) {
    const router = express.Router();
    router.get('/health', (_req, res) => {
        res.json({ ok: true, build: BUILD_NAME, version: BUILD_VERSION, host });
    });
    router.get('/diagnostics', async (_req, res) => {
        try {
            res.json(await getDiagnostics(host));
        }
        catch (error) {
            fail(res, 500, 'Diagnostics could not be collected.', error.message);
        }
    });
    // Lets the operator see the route plan before spending a run on it.
    router.post('/plan', (req, res) => {
        const query = asString(req.body?.query).trim();
        if (!query)
            return fail(res, 400, 'A query is required.');
        if (query.length > MAX_QUERY_LENGTH) {
            return fail(res, 400, `A query must be ${MAX_QUERY_LENGTH} characters or fewer.`);
        }
        return res.json(planQuery(query));
    });
    /**
     * Runs one extraction.
     *
     * The response is newline-delimited JSON so the live route reaches the browser
     * while the run is still going: every line is a `step` event and the last line
     * is either a `result` or an `error`. A client that does not want the live
     * route can simply read to the end and take the final line.
     */
    router.post('/extract', async (req, res) => {
        const body = (req.body ?? {});
        const query = asString(body.query).trim();
        if (!query) {
            return fail(res, 400, 'A query is required.', 'Send a JSON body of the form { "query": "..." }.');
        }
        if (query.length > MAX_QUERY_LENGTH) {
            return fail(res, 400, `A query must be ${MAX_QUERY_LENGTH} characters or fewer.`);
        }
        const preserved = body.preservedFields;
        const preservedFields = preserved && typeof preserved === 'object' && !Array.isArray(preserved)
            ? preserved
            : undefined;
        res.status(200);
        res.setHeader('Content-Type', 'application/x-ndjson; charset=utf-8');
        res.setHeader('Cache-Control', 'no-store');
        // Proxies that buffer would defeat the point of streaming the route.
        res.setHeader('X-Accel-Buffering', 'no');
        const send = (event) => {
            if (!res.writableEnded)
                res.write(`${JSON.stringify(event)}\n`);
        };
        try {
            const result = await extract(query, {
                deepScan: body.deepScan !== false,
                peopleSearch: body.peopleSearch === true,
                useAssistant: body.useAssistant !== false,
                budgetMs: typeof body.budgetMs === 'number' ? body.budgetMs : undefined,
                rowId: asString(body.rowId) || undefined,
                preservedFields,
                onStep: (step) => send({ type: 'step', step }),
            });
            send({ type: 'result', result });
        }
        catch (error) {
            send({ type: 'error', error: 'The extraction run failed.', detail: error.message });
        }
        return res.end();
    });
    router.get('/learning', (_req, res) => {
        res.json(learningSnapshot());
    });
    router.post('/learning/reset', (_req, res) => {
        resetLearning();
        res.json({ ok: true, learning: learningSnapshot() });
    });
    router.post('/diagnostics/reset', (_req, res) => {
        resetEngineStats();
        res.json({ ok: true });
    });
    return router;
}
/** Builds the Express application shared by the local server and the Vercel function. */
export function createApp(host) {
    const app = express();
    app.disable('x-powered-by');
    app.use(express.json({ limit: '1mb' }));
    app.use('/api', createApiRouter(host));
    app.use('/api', (_req, res) => {
        fail(res, 404, 'No such API endpoint.');
    });
    // Express reports body-parser failures here; without this the client sees an
    // HTML error page instead of the JSON error shape it expects.
    app.use((error, _req, res, _next) => {
        fail(res, 400, 'The request body could not be read.', error.message);
    });
    return app;
}
//# sourceMappingURL=app.js.map