# Forge CRM 0.16

```bash
npm install
npm run dev
```

Open http://localhost:3000
