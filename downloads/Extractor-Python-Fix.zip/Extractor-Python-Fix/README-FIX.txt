PYTHON VENV FIX
===============
Copy these files into your existing Extractor folder (overwrite):

  server\transportClient.ts
  desktop\START-EXTRACTOR.bat
  desktop\START-SERVER.bat
  desktop\lib\common.sh

Then:
1. desktop\STOP-EXTRACTOR.bat
2. desktop\Install-Full-Browsers.bat   (only if this folder never had browsers)
3. desktop\START-EXTRACTOR.bat
4. Diagnostics should show curl_cffi / patchright / camoufox available
